#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid1 = fork();
    
    if (pid1 == 0) {
        // First child process
        execl("/bin/ls", "ls", NULL);
    } else {
        pid_t pid2 = fork();
        
        if (pid2 == 0) {
            // Second child process
            execl("/bin/date", "date", NULL);
        } else {
            // Parent process
            wait(NULL);
            wait(NULL);
            printf("Parent process done\n");
        }
    }
    
    return 0;
}

*/
Analysis:
   Two fork() calls are used to create two child processes.
   The first child runs the ls command, and the second child runs the date command.
   The parent creates two child processes. The first child executes ls, and the second child executes date. The parent waits for both children to finish and prints "Parent process done."
*/