#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();
    
    if (pid == 0) {
        // Child process
        execl("/bin/grep", "grep", "main", "test.txt", NULL);
    } else {
        // Parent process
        wait(NULL);
        printf("Parent process completed\n");
    }
    
    return 0;
}

*/Analysis:
	execl("/bin/grep", "grep", "main", "test.txt", NULL) executes grep with the arguments to search for "main" in test.txt.
	The child searches the file for the word "main". The parent waits and prints "Parent process completed" once the child finishes.
*/