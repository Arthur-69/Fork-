#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();
    
    if (pid == 0) {
        // Child process
        execl("/bin/ls", "ls", NULL);
    } else {
        // Parent process
        wait(NULL); // Wait for child process to complete
        printf("Parent process done\n");
    }
    
    return 0;
}

*/Analysis:
   fork(): Creates a child process.
   execl(): Replaces the child process image with the ls program to list the contents of the current directory.
   wait(): Ensures the parent waits for the child process to finish execution.
   The parent process forks a child, which then executes the ls command. Once the child process completes, the parent prints "Parent process done."
   The parent creates one child process, which replaces its execution with the ls command. No additional processes are created.
*/