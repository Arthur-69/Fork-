#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main() {
    fork();
    fork();
    fork();
    
    return 0;
}

*/Analysis: 
   After three fork() calls, eight processes are created: one parent and seven child processes.
   The first fork() creates a child process. Both parent and child continue and execute the second fork(), resulting in four processes. The third fork() doubles the number of processes again to eight.
   Each parent process creates a child process that executes the subsequent fork() calls independently. The process tree is branched out recursively.
 */