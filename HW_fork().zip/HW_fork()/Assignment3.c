#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();
    
    if (pid == 0) {
        // Child process
        execl("/bin/echo", "echo", "Hello from the child process", NULL);
    } else {
        // Parent process
        wait(NULL);
        printf("Parent process done\n");
    }
    
    return 0;
}

*/Analysis:
    execl("/bin/echo", "echo", "Hello from the child process", NULL) executes the echo command with the argument "Hello from the child process".
	The child prints the message passed as an argument to echo. The parent waits for the child to finish and prints "Parent process done."

*/